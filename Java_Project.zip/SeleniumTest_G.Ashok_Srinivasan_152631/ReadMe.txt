Due to some issue, the project may not run properly.
In order to run the file successfully, Please right click on the feature files and run it as cucumber feature.
Thank you for your time and patience.