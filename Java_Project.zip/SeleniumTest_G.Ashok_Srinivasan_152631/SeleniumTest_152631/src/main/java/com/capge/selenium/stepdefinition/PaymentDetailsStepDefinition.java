package com.capge.selenium.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capge.selenium.bean.PaymentDetailsBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentDetailsStepDefinition {

	private WebDriver driver;
	private PaymentDetailsBean pageBeanPayment;

	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\bdd-srini\\Selenium\\chromedriver.exe");
	}
	
	

	@Given("^User is on Payment Details page$")
	public void user_is_on_Payment_Details_page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("D:\\Ashok_bdd\\SeleniumTest_152631\\PaymentDetails.html");
		driver.manage().window().maximize();
		pageBeanPayment = new PaymentDetailsBean();
		PageFactory.initElements(driver, pageBeanPayment);

	}

	@When("^User selects 'Make Payment' without entering 'Card Holder Name'$")
	public void user_selects_Make_Payment_without_entering_Card_Holder_Name() throws Throwable {

		pageBeanPayment.clickPaymentButton();

	}

	@Then("^'Please fill card holder name' should display$")
	public void please_fill_card_holder_name_should_display() throws Throwable {

		Thread.sleep(3000);
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Card Holder Name";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Make Payment' without entering 'Debit Card Number'$")
	public void user_selects_Make_Payment_without_entering_Debit_Card_Number() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBeanPayment.setCardHolderName("Ashok Srinivasan");
		pageBeanPayment.clickPaymentButton();

	}

	@Then("^'Please fill debit card number' should display$")
	public void please_fill_debit_card_number_should_display() throws Throwable {
		Thread.sleep(3000);
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Debit Card Number";
		Assert.assertEquals(expectedMessage, actualMessage);

	}

	@When("^User selects 'Make Payment' without entering 'CVV'$")
	public void user_selects_Make_Payment_without_entering_CVV() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBeanPayment.setDebit("123454641212");
		pageBeanPayment.clickPaymentButton();

	}

	@Then("^'Please fill CVV' should display$")
	public void please_fill_CVV_should_display() throws Throwable {
		Thread.sleep(3000);
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the CVV";
		Assert.assertEquals(expectedMessage, actualMessage);

	}

	@When("^User selects 'Make Payment' without entering 'Expiration Month'$")
	public void user_selects_Make_Payment_without_entering_Expiration_Month() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBeanPayment.setCvv("965");
		pageBeanPayment.clickPaymentButton();
	}

	@Then("^'Please fill Expiration Month' should display$")
	public void please_fill_Expiration_Month_should_display() throws Throwable {
		Thread.sleep(3000);
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Expiration Month";
		Assert.assertEquals(expectedMessage, actualMessage);

	}

	@When("^User selects 'Make Payment' without entering 'Expiration year'$")
	public void user_selects_Make_Payment_without_entering_Expiration_year() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBeanPayment.setMonth("07");
		pageBeanPayment.clickPaymentButton();
	}

	@Then("^'Please fill Expiration Year' should display$")
	public void please_fill_Expiration_Year_should_display() throws Throwable {
		Thread.sleep(3000);
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Expiration Year";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User selects 'Make Payment' after entering all valid details$")
	public void user_selects_Make_Payment_after_entering_all_valid_details() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBeanPayment.setCardHolderName("Ashok Srinivasan");
		pageBeanPayment.setDebit("123454641212");
		pageBeanPayment.setCvv("965");
		pageBeanPayment.setMonth("07");
		pageBeanPayment.setYear("23");
		pageBeanPayment.clickPaymentButton();

	}

	@Then("^'Payment Success' should display$")
	public void payment_Success_should_display() throws Throwable {
		Thread.sleep(3000);
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Payment Successful.";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		Thread.sleep(2000);
		driver.close();

	}

}
