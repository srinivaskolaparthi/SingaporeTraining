package com.capge.selenium.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PaymentDetailsBean {
	
	@FindBy(how = How.ID, id = "txtCardholderName")
	private WebElement cardHolderName;
	
	@FindBy(how = How.ID, id = "txtDebit")
	private WebElement debit;
	
	@FindBy(how = How.ID, id = "txtCvv")
	private WebElement cvv;
	
	@FindBy(how = How.ID, id = "txtMonth")
	private WebElement month;
	
	@FindBy(how = How.ID, id = "txtYear")
	private WebElement year;
	
	@FindBy(how = How.ID, id = "btnPayment")
	private WebElement button;
	
	public void clickPaymentButton() {
		button.click();
	}

	public String getCardHolderName() {
		
		return cardHolderName.getAttribute("value");
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.clear();
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public String getDebit() {
		return debit.getAttribute("value");
	}

	public void setDebit(String debit) {
		this.debit.clear();
		this.debit.sendKeys(debit);
	}

	public String getCvv() {
		return cvv.getAttribute("value");
	}

	public void setCvv(String cvv) {
		this.cvv.clear();
		this.cvv.sendKeys(cvv);
	}

	public String getMonth() {
		return month.getAttribute("value");
	}

	public void setMonth(String month) {
		this.month.clear();
		this.month.sendKeys(month);
	}

	public String getYear() {
		return year.getAttribute("value");
	}

	public void setYear(String year) {
		this.year.clear();
		this.year.sendKeys(year);
	}

}
